package mw_jk_project_01;

public abstract class ResumeItems {
	
	
	
	
	public abstract String toString ();
	
}
