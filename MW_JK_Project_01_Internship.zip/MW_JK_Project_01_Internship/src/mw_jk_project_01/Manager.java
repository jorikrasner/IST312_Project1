package mw_jk_project_01;

public class Manager {
	//Attributes
		private int editor;
		private int manager;
		
}
